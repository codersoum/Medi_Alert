function showlogin()
 {
   window.location.href="http://localhost:5050/login.html"
 }
 function showsignup()
 {
   window.location.href="http://localhost:5050/register.html"
 }
